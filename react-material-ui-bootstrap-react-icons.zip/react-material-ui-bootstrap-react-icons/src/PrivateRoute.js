import React from "react";
import { Route } from "react-router-dom";

const PrivateRoute = ({ children, ...rest }) => {
  const token = localStorage.getItem("access_token") || null;

  if (!token) {
    window.location.href = "/login";
    return null;
  }
  return <Route {...rest}>{children}</Route>;
};

export default PrivateRoute;
