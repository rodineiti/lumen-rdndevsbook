import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { Redirect, Link } from "react-router-dom";
import { Button, TextField, Typography, withStyles } from "@material-ui/core";
import { changeAuth, login } from "../../store/actions/auth.actions";

const RegisterButton = withStyles((theme) => ({
  root: {
    color: "#fff",
    backgroundColor: "#28a745",
    "&:hover": {
      backgroundColor: "#218838",
      color: "#fff"
    }
  }
}))(Button);

export default function Login() {
  const dispatch = useDispatch();
  const { credentials, success } = useSelector((state) => state.authReducer);

  return (
    <div className="d-flex bg-white min-vh-100">
      <div className="container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-4">
            <div className="form-group text-center">
              <img src="/logo.png" alt="CAR CRM" height="48" />
              <Typography variant="h6" component="h1" className="mt-3">
                Plataforma para Revenda de veículos
              </Typography>
            </div>
            <TextField
              margin="normal"
              label="E-mail"
              type="email"
              autoComplete="email"
              value={credentials.email}
              onChange={(event) =>
                dispatch(changeAuth({ email: event.target.value }))
              }
            />

            <TextField
              margin="normal"
              label="Senha"
              type="password"
              value={credentials.password}
              onChange={(event) =>
                dispatch(changeAuth({ password: event.target.value }))
              }
            />

            <Button
              variant="contained"
              color="primary"
              fullWidth
              size="large"
              className="mt-4 mb-4"
              onClick={() => dispatch(login(credentials))}
            >
              Entrar
            </Button>

            <RegisterButton
              component={Link}
              to="/registro"
              variant="contained"
              fullWidth
              size="large"
              className="mt-4 mb-4"
            >
              Fazer Cadastro
            </RegisterButton>

            {success ||
              (localStorage.getItem("access_token") && (
                <Redirect to="/veiculos" />
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
