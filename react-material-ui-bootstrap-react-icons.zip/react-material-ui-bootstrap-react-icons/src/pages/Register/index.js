import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { Redirect, Link } from "react-router-dom";
import { Button, TextField, Typography, withStyles } from "@material-ui/core";
import { changeRegister, register } from "../../store/actions/register.actions";

const LoginButton = withStyles((theme) => ({
  root: {
    color: "#fff",
    backgroundColor: "#28a745",
    "&:hover": {
      backgroundColor: "#218838",
      color: "#fff"
    }
  }
}))(Button);

export default function Register() {
  const dispatch = useDispatch();
  const { formData, success, error } = useSelector(
    (state) => state.registerReducer
  );

  return (
    <div className="d-flex bg-white min-vh-100">
      <div className="container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-4">
            <div className="form-group text-center">
              <img src="/logo.png" alt="CAR CRM" height="48" />
              <Typography variant="h6" component="h1" className="mt-3">
                Plataforma para Revenda de veículos
              </Typography>
            </div>
            <TextField
              margin="normal"
              label="Nome"
              type="text"
              autoComplete="name"
              value={formData.name}
              onChange={(event) =>
                dispatch(changeRegister({ name: event.target.value }))
              }
            />
            {error && error.name && (
              <strong className="text-danger">{error.name[0]}</strong>
            )}

            <TextField
              margin="normal"
              label="E-mail"
              type="email"
              autoComplete="email"
              value={formData.email}
              onChange={(event) =>
                dispatch(changeRegister({ email: event.target.value }))
              }
            />

            {error && error.email && (
              <strong className="text-danger">{error.email[0]}</strong>
            )}

            <TextField
              margin="normal"
              label="Senha"
              type="password"
              value={formData.password}
              onChange={(event) =>
                dispatch(changeRegister({ password: event.target.value }))
              }
            />

            {error && error.password && (
              <strong className="text-danger">{error.password[0]}</strong>
            )}

            <TextField
              margin="normal"
              label="Confirmar senha"
              type="password"
              value={formData.password_confirmation}
              onChange={(event) =>
                dispatch(
                  changeRegister({ password_confirmation: event.target.value })
                )
              }
            />

            {error && error.password_confirmation && (
              <strong className="text-danger">
                {error.password_confirmation[0]}
              </strong>
            )}

            <Button
              variant="contained"
              color="primary"
              fullWidth
              size="large"
              className="mt-4 mb-4"
              onClick={() => dispatch(register(formData))}
            >
              Cadastrar
            </Button>

            <LoginButton
              component={Link}
              to="/login"
              variant="contained"
              fullWidth
              size="large"
              className="mt-4 mb-4"
            >
              Fazer Login
            </LoginButton>

            {success ||
              (localStorage.getItem("access_token") && (
                <Redirect to="/veiculos" />
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
