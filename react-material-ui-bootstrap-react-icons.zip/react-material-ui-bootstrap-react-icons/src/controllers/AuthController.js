import api from "../services/api";
const version = "api/v2";

class AuthController {
  constructor() {
    this.version = version;
  }

  async login(email, password) {
    const data = {
      grant_type: "password",
      client_id: "2",
      client_secret: "aClECVmq39o6ToTutTPdfUleMRYWll6AIk2RvHG6",
      username: email,
      password: password
    };
    const response = await api.post(`/oauth/token`, data);
    return response;
  }

  async register(name, email, password, password_confirmation) {
    const response = await api.post(`${this.version}/auth/register`, {
      name,
      email,
      password,
      password_confirmation
    });
    return response;
  }

  async me() {
    const response = await api.get(`${this.version}/auth/me`);
    return response;
  }

  async updateProfile(name, email, password = null) {
    let data = {
      name,
      email
    };

    if (password) {
      data.password = password;
      data.password_confirmation = password;
    }

    const response = await api.post(`${this.version}/auth/updateProfile`, data);
    return response;
  }

  async logout() {
    const response = await api.get(`${this.version}/auth/logout`);
    return response;
  }
}

export default new AuthController();
