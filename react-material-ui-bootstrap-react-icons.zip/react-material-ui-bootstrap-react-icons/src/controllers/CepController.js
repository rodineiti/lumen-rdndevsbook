import api from "../services/api";
const version = "api/v2";

class CepController {
  constructor() {
    this.version = version;
  }

  async show(cep) {
    const response = await api.get(`${this.version}/cep/${cep}`);
    return response;
  }
}

export default new CepController();
