import api from "../services/api";
const version = "api/v2";

class VehicleImageController {
  constructor(upload = false) {
    this.version = version;
    this.upload = upload;

    if (this.upload) {
      this.config = { headers: { "Content-Type": "multipart/form-data" } };
    }
  }

  async store(formData) {
    const response = await api.post(
      `${this.version}/vehicles_images/upload`,
      formData,
      this.config
    );
    return response;
  }

  async destroy(id) {
    const response = await api.delete(`${this.version}/vehicles_images/${id}`);
    return response;
  }
}

export default VehicleImageController;
