import api from "../services/api";
const version = "api/v2";

class VehiclesController {
  constructor(upload = false) {
    this.version = version;
    this.upload = upload;

    if (this.upload) {
      this.config = { headers: { "Content-Type": "multipart/form-data" } };
    }
  }

  async getData() {
    const response = await api.get(`${this.version}/getcombo`);
    return response;
  }

  async index(page = 1, paginate = false, search = null) {
    const response = await api.get(
      `${this.version}/vehicles?paginate=${paginate}&page=${page}&term=${search}`
    );
    return response;
  }

  async store(formData) {
    const response = await api.post(
      `${this.version}/vehicles`,
      formData,
      this.config
    );
    return response;
  }

  async show(id) {
    const response = await api.get(`${this.version}/vehicles/${id}`);
    return response;
  }

  async update(id, formData) {
    const method = this.upload ? "post" : "put";
    const response = await api[method](
      `${this.version}/vehicles/${id}`,
      formData,
      this.config
    );
    return response;
  }

  async destroy(id) {
    const response = await api.delete(`${this.version}/vehicles/${id}`);
    return response;
  }

  async brand(vehicle_type) {
    const response = await api.get(
      `${this.version}/vehicles/${vehicle_type}/brand`
    );
    return response;
  }

  async model(vehicle_type, vehicle_brand) {
    const response = await api.get(
      `${this.version}/vehicles/${vehicle_type}/${vehicle_brand}/model`
    );
    return response;
  }

  async getVersion(vehicle_brand, vehicle_model) {
    const response = await api.get(
      `${this.version}/vehicles/${vehicle_brand}/${vehicle_model}/version`
    );
    return response;
  }
}

export default VehiclesController;
