import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8000/"
});

api.interceptors.request.use(
  async (config) => {
    let token = null;
    const rootPersist = localStorage.getItem("access_token");

    if (rootPersist) {
      token = rootPersist;
    }

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (err) => {
    return Promise.reject(err);
  }
);

api.interceptors.response.use(
  (response) => {
    return response;
  },
  (err) => {
    return Promise.reject(err);
  }
);

export default api;
