export const actionTypes = {
  CHANGE: "CHANGE_LOADING"
};

export const changeLoaging = (payload) => ({
  type: actionTypes.CHANGE,
  payload
});
