import CepController from "../../controllers/CepController";
import VehiclesController from "../../controllers/VehiclesController";
import VehicleImageController from "../../controllers/VehicleImageController";
import { changeLoaging } from "./loading.actions";
import { changeNotify } from "./notify.actions";

const controller = new VehiclesController();
const controllerUpload = new VehicleImageController(true);

export const actionTypes = {
  GET_DATA: "VEHICLE_GET_DATA",
  INDEX: "VEHICLE_INDEX",
  UPDATE: "VEHICLE_UPDATE",
  DESTROY: "VEHICLE_DESTROY",
  CHANGE: "VEHICLE_CHANGE",
  UPLOAD_PHOTO: "VEHICLE_UPLOAD_PHOTO",
  DELETE_PHOTO: "VEHICLE_DELETE_PHOTO",
  REORDER_PHOTO: "VEHICLE_REORDER_PHOTO",
  SUCCESS: "VEHICLE_SUCCESS",
  ERROR: "VEHICLE_ERROR",
};

export const changeGetData = (payload) => ({
  type: actionTypes.GET_DATA,
  payload,
});

export const changeVehicle = (payload) => ({
  type: actionTypes.CHANGE,
  payload,
});

export const successVehicle = (payload) => ({
  type: actionTypes.SUCCESS,
  payload,
});

export const errorVehicle = (payload) => ({
  type: actionTypes.ERROR,
  payload,
});

export const indexResponse = (payload, type, isLoadMore) => ({
  type: actionTypes.INDEX,
  payload,
  isLoadMore,
});

export const getData = () => async (dispatch) => {
  dispatch(changeLoaging({ open: true, message: "Carregando dados..." }));

  try {
    const response = await controller.getData();

    dispatch(changeLoaging({ open: false }));

    if (response && response.data && !response.data.error) {
      dispatch(changeGetData(response.data.data));
    } else {
      dispatch(
        changeNotify({
          open: true,
          message: "Não foram encontrados registros de veículos",
          class: "error",
        })
      );
    }
  } catch (error) {
    dispatch(changeLoaging({ open: false }));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500)
    ) {
      dispatch(
        changeNotify({
          open: true,
          message: "Ocorreu um erro no servidor, favor tente mais tarde",
          class: "error",
        })
      );
    }
  }
};

export const index = (query, isLoadMore) => async (dispatch) => {
  dispatch(changeLoaging({ open: true, message: "Carregando dados..." }));

  try {
    const response = await controller.index(1, false, query);

    dispatch(changeLoaging({ open: false }));

    if (response && response.data && !response.data.error) {
      dispatch(indexResponse(response.data.data, isLoadMore));
    } else {
      dispatch(
        changeNotify({
          open: true,
          message: "Não foram encontrados registros de veículos",
          class: "error",
        })
      );
    }
  } catch (error) {
    dispatch(changeLoaging({ open: false }));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500)
    ) {
      dispatch(
        changeNotify({
          open: true,
          message: "Ocorreu um erro no servidor, favor tente mais tarde",
          class: "error",
        })
      );
    }
  }
};

export const store = (formData) => async (dispatch) => {
  dispatch(changeLoaging({ open: true, message: "Salvando dados..." }));

  try {
    const response = await controller.store(formData);

    dispatch(changeLoaging({ open: false }));

    if (response && response.data && !response.data.error) {
      dispatch(indexResponse(response.data.data));
      dispatch(
        changeNotify({
          open: true,
          message: response.data.message,
          class: "success",
        })
      );
    } else {
      dispatch(
        changeNotify({
          open: true,
          message: "Não foi possível salvar os dados",
          class: "error",
        })
      );
    }
  } catch (error) {
    dispatch(changeLoaging({ open: false }));
    dispatch(errorVehicle(error.response ? error.response.data.errors : error));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500)
    ) {
      dispatch(
        changeNotify({
          open: true,
          message: "Ocorreu um erro no servidor, favor tente mais tarde",
          class: "error",
        })
      );
    }
  }
};

export const show = (id) => async (dispatch) => {
  dispatch(changeLoaging({ open: true, message: "Resgatando dados..." }));

  try {
    const response = await controller.show(id);

    dispatch(changeLoaging({ open: false }));

    if (response && response.data && !response.data.error) {
      dispatch(indexResponse({ vehicle: response.data.data }));
    } else {
      dispatch(
        changeNotify({
          open: true,
          message: "Não foi possível resgatar os dados",
          class: "error",
        })
      );
    }
  } catch (error) {
    dispatch(changeLoaging({ open: false }));
    dispatch(errorVehicle(error.response ? error.response.data.errors : error));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500)
    ) {
      dispatch(
        changeNotify({
          open: true,
          message: "Ocorreu um erro no servidor, favor tente mais tarde",
          class: "error",
        })
      );
    }
  }
};

export const update = (id, formData) => async (dispatch) => {
  dispatch(changeLoaging({ open: true, message: "Salvando dados..." }));

  try {
    const response = await controller.update(id, formData);

    dispatch(changeLoaging({ open: false }));

    if (response && response.data && !response.data.error) {
      dispatch(successVehicle(true));
      dispatch(
        changeNotify({
          open: true,
          message: response.data.message,
          class: "success",
        })
      );
    } else {
      dispatch(successVehicle(false));
      dispatch(errorVehicle(response.data));
    }
  } catch (error) {
    dispatch(changeLoaging({ open: false }));
    dispatch(errorVehicle(error.response ? error.response.data.errors : error));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500)
    ) {
      dispatch(
        changeNotify({
          open: true,
          message: "Ocorreu um erro no servidor, favor tente mais tarde",
          class: "error",
        })
      );
    }
  }
};

export const destroyResponse = (payload) => ({
  type: actionTypes.DESTROY,
  payload,
});

export const destroy = (id) => async (dispatch) => {
  dispatch(changeLoaging({ open: true, message: "Salvando dados..." }));

  try {
    const response = await controller.destroy(id);

    dispatch(changeLoaging({ open: false }));

    if (response && response.data && !response.data.error) {
      dispatch(destroyResponse(response.data.id));
      dispatch(successVehicle(true));
    } else {
      dispatch(successVehicle(false));
      dispatch(errorVehicle(response.data.error));
    }
  } catch (error) {
    dispatch(changeLoaging({ open: false }));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500)
    ) {
      dispatch(
        changeNotify({
          open: true,
          message: "Ocorreu um erro no servidor, favor tente mais tarde",
          class: "error",
        })
      );
    }
  }
};

export const brand = (vehicle_type) => async (dispatch) => {
  dispatch(changeLoaging({ open: true, message: "Carregando dados..." }));

  try {
    const response = await controller.brand(vehicle_type);

    dispatch(changeLoaging({ open: false }));

    if (response && response.data && !response.data.error) {
      dispatch(changeGetData({ vehicle_brand: response.data.data }));
    } else {
      dispatch(
        changeNotify({
          open: true,
          message: "Não foram encontrados registros de marcas",
          class: "error",
        })
      );
    }
  } catch (error) {
    dispatch(changeLoaging({ open: false }));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500)
    ) {
      dispatch(
        changeNotify({
          open: true,
          message: "Ocorreu um erro no servidor, favor tente mais tarde",
          class: "error",
        })
      );
    }
  }
};

export const model = (vehicle_type, vehicle_brand) => async (dispatch) => {
  dispatch(changeLoaging({ open: true, message: "Carregando dados..." }));

  try {
    const response = await controller.model(vehicle_type, vehicle_brand);

    dispatch(changeLoaging({ open: false }));

    if (response && response.data && !response.data.error) {
      dispatch(changeGetData({ vehicle_model: response.data.data }));
    } else {
      dispatch(
        changeNotify({
          open: true,
          message: "Não foram encontrados registros de modelos",
          class: "error",
        })
      );
    }
  } catch (error) {
    dispatch(changeLoaging({ open: false }));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500)
    ) {
      dispatch(
        changeNotify({
          open: true,
          message: "Ocorreu um erro no servidor, favor tente mais tarde",
          class: "error",
        })
      );
    }
  }
};

export const version = (vehicle_brand, vehicle_model) => async (dispatch) => {
  console.log(vehicle_brand, vehicle_model);
  dispatch(changeLoaging({ open: true, message: "Carregando dados..." }));

  try {
    const response = await controller.getVersion(vehicle_brand, vehicle_model);

    dispatch(changeLoaging({ open: false }));

    if (response && response.data && !response.data.error) {
      dispatch(changeGetData({ vehicle_version: response.data.data }));
    } else {
      dispatch(
        changeNotify({
          open: true,
          message: "Não foram encontrados registros de versões",
          class: "error",
        })
      );
    }
  } catch (error) {
    console.log(error);
    dispatch(changeLoaging({ open: false }));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500)
    ) {
      dispatch(
        changeNotify({
          open: true,
          message: "Ocorreu um erro no servidor, favor tente mais tarde",
          class: "error",
        })
      );
    }
  }
};

export const cep = (zipCode) => async (dispatch) => {
  try {
    const response = await CepController.show(zipCode);
    console.log(response);
    if (response && response.data && !response.data.error) {
      dispatch(changeVehicle(response.data.data));
    } else {
      dispatch(
        changeNotify({
          open: true,
          message: "Não foi possível resgatar os dados",
          class: "error",
        })
      );
    }
  } catch (error) {
    console.log(error);
    dispatch(changeLoaging({ open: false }));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500)
    ) {
      dispatch(
        changeNotify({
          open: true,
          message: "Ocorreu um erro no servidor, favor tente mais tarde",
          class: "error",
        })
      );
    }
  }
};

export const uploadPhotoResponse = (payload) => ({
  type: actionTypes.UPLOAD_PHOTO,
  payload,
});

export const uploadPhoto = (formData) => async (dispatch) => {
  dispatch(changeLoaging({ open: true, message: "Salvando dados..." }));

  try {
    const response = await controllerUpload.store(formData);

    dispatch(changeLoaging({ open: false }));

    if (response && response.data && !response.data.error) {
      dispatch(successVehicle(true));
      dispatch(uploadPhotoResponse(response.data.data));
    } else {
      dispatch(successVehicle(false));
      dispatch(errorVehicle(response.data.error));
    }
  } catch (error) {
    dispatch(changeLoaging({ open: false }));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500)
    ) {
      dispatch(
        changeNotify({
          open: true,
          message: "Ocorreu um erro no servidor, favor tente mais tarde",
          class: "error",
        })
      );
    }
  }
};

export const deletePhotoResponse = (payload) => ({
  type: actionTypes.DELETE_PHOTO,
  payload,
});

export const deletePhoto = (id) => async (dispatch) => {
  dispatch(changeLoaging({ open: true, message: "Deletando dados..." }));

  try {
    const response = await controllerUpload.destroy(id);

    dispatch(changeLoaging({ open: false }));

    if (response && response.data && !response.data.error) {
      dispatch(deletePhotoResponse(id));
      dispatch(
        changeNotify({
          open: true,
          message: response.data.message,
          class: "success",
        })
      );
      dispatch(successVehicle(true));
    } else {
      dispatch(successVehicle(false));
      dispatch(errorVehicle(response.data.error));
    }
  } catch (error) {
    dispatch(changeLoaging({ open: false }));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500)
    ) {
      dispatch(
        changeNotify({
          open: true,
          message: "Ocorreu um erro no servidor, favor tente mais tarde",
          class: "error",
        })
      );
    }
  }
};

export const reorderPhotoResponse = (payload) => ({
  type: actionTypes.REORDER_PHOTO,
  payload,
});
