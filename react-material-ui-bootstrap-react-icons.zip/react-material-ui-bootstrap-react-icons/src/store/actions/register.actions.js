import AuthController from "../../controllers/AuthController";
import { changeLoaging } from "./loading.actions";
import { changeNotify } from "./notify.actions";

export const actionTypes = {
  CHANGE: "CHANGE_REGISTER",
  SUCCESS: "SUCCESS_REGISTER",
  ERROR: "ERROR_REGISTER"
};

export const changeRegister = (payload) => ({
  type: actionTypes.CHANGE,
  payload
});

export const successRegister = (payload) => ({
  type: actionTypes.SUCCESS,
  payload
});

export const errorRegister = (payload) => ({
  type: actionTypes.ERROR,
  payload
});

export const setUserToken = (token) => (dispatch) => {
  localStorage.setItem("access_token", token);
  dispatch(
    changeRegister({
      name: "",
      email: "",
      password: "",
      password_confirmation: ""
    })
  );
  dispatch(successRegister(true));
};

export const register = (formData) => async (dispatch) => {
  dispatch(changeLoaging({ open: true, message: "Cadastrando usuário" }));

  try {
    const response = await AuthController.register(
      formData.name,
      formData.email,
      formData.password,
      formData.password_confirmation
    );

    dispatch(changeLoaging({ open: false }));

    if (response && response.data && !response.data.error) {
      dispatch(
        changeNotify({
          open: true,
          message: "Usuário cadastrado com sucesso",
          class: "success"
        })
      );
      dispatch(setUserToken(response.data.access_token));
    } else {
      dispatch(
        changeNotify({
          open: true,
          message:
            "Não foi possível realizar o cadastro, favor tente mais tarde.",
          class: "error"
        })
      );
    }
  } catch (error) {
    dispatch(changeLoaging({ open: false }));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500 ||
        error.response.status === 422)
    ) {
      if (error.response.status === 422) {
        dispatch(errorRegister(error.response.data));
      } else {
        dispatch(
          changeNotify({
            open: true,
            message:
              "Não foi possível realizar o cadastro, favor tente mais tarde.",
            class: "error"
          })
        );
      }
    }
  }
};
