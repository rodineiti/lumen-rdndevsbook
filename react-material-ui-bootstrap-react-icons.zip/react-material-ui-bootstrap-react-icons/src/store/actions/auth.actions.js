import AuthController from "../../controllers/AuthController";
import { changeLoaging } from "./loading.actions";
import { changeNotify } from "./notify.actions";

export const actionTypes = {
  CHANGE: "CHANGE_AUTH",
  SUCCESS: "SUCCESS_AUTH",
};

export const changeAuth = (payload) => ({
  type: actionTypes.CHANGE,
  payload,
});

export const successAuth = (payload) => ({
  type: actionTypes.SUCCESS,
  payload,
});

export const setUserToken = (token) => (dispatch) => {
  localStorage.setItem("access_token", token);
  dispatch(changeAuth({ email: "", password: "" }));
  dispatch(successAuth(true));
};

export const login = (credentials) => async (dispatch) => {
  dispatch(changeLoaging({ open: true, message: "Autenticando usuário" }));

  try {
    const response = await AuthController.login(
      credentials.email,
      credentials.password
    );

    dispatch(changeLoaging({ open: false }));

    if (response && response.data && !response.data.error) {
      dispatch(setUserToken(response.data.access_token));
    }
  } catch (error) {
    dispatch(changeLoaging({ open: false }));
    if (
      error &&
      error.response &&
      (error.response.status === 401 ||
        error.response.status === 400 ||
        error.response.status === 500)
    ) {
      dispatch(
        changeNotify({
          open: true,
          message: "E-mail ou senha incorretos",
          class: "error",
        })
      );
    }
  }
};

export const setLogout = () => (dispatch) => {
  localStorage.removeItem("access_token");
  dispatch(successAuth(true));
};

export const logout = () => async (dispatch) => {
  dispatch(changeLoaging({ open: true, message: "Logout usuário" }));

  dispatch(setLogout());

  dispatch(changeLoaging({ open: false }));
};
