import { actionTypes } from "../actions/register.actions";

const initialState = {
  formData: { name: "", email: "", password: "", password_confirmation: "" },
  success: false,
  error: {}
};

export default (state = initialState, { type, payload }) => {
  switch (type) {
    case actionTypes.CHANGE:
      return {
        ...state,
        formData: {
          ...state.formData,
          ...payload
        }
      };
    case actionTypes.SUCCESS:
      return {
        ...state,
        success: payload
      };
    case actionTypes.ERROR:
      return {
        ...state,
        error: payload
      };
    default:
      return state;
  }
};
