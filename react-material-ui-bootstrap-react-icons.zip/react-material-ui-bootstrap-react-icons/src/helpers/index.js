export const redirectTo = (uri) => {
  window.location.href = uri;
};
