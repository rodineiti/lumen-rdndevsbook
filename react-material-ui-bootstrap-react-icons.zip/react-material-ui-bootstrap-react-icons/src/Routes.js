import React, { Suspense, lazy } from "react";
import { Route, Switch, Redirect } from "react-router-dom";
import { CircularProgress } from "@material-ui/core";

// const Login = lazy(() => import("./pages/Login"));
// const Register = lazy(() => import("./pages/Register"));
// const Vehicles = lazy(() => import("./pages/Vehicles"));
// const VehicleEdit = lazy(() => import("./pages/Vehicles/edit"));

import Login from "./pages/Login";
import Register from "./pages/Register";
import Vehicles from "./pages/Vehicles";
import VehicleEdit from "./pages/Vehicles/edit";

import PrivateRoute from "./PrivateRoute";

const Routes = () => {
  return (
    <Suspense
      fallback={
        <div className="d-flex justify-content-center mt-5 pt-5">
          <CircularProgress />
        </div>
      }
    >
      <Switch>
        <Route exact path="/" component={Login} />
        <Route exact path="/login" component={Login} />
        <Route exact path="/registro" component={Register} />
        <PrivateRoute exact path="/veiculos" component={Vehicles} />
        <PrivateRoute exact path="/veiculos/criar" component={VehicleEdit} />
        <PrivateRoute
          exact
          path="/veiculos/editar/:id"
          component={VehicleEdit}
        />
        <Redirect from="*" to="/" />
      </Switch>
    </Suspense>
  );
};

export default Routes;
