import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import {
  FaCar,
  FaUsers,
  FaLaptop,
  FaCreditCard,
  FaWhatsapp,
  FaSignOutAlt,
  FaAngleUp,
  FaAngleDown,
} from "react-icons/fa";
import { MdMenu } from "react-icons/md";
import {
  MenuList,
  MenuItem,
  IconButton,
  AppBar,
  Toolbar,
  Typography,
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Divider,
  Collapse,
} from "@material-ui/core";
import { logout } from "../../store/actions/auth.actions";

export default function Header({ title, button }) {
  const dispatch = useDispatch();
  const [menuOpen, setMenuOpen] = useState(false);
  const [collapseSite, setCollapseSite] = useState(false);
  const [collapseFinance, setCollapseFinance] = useState(false);
  return (
    <>
      {window.innerWidth < 577 ? (
        <AppBar position="fixed">
          <Toolbar>
            <IconButton
              edge="start"
              color="inherit"
              aria-label="menu"
              onClick={() => setMenuOpen(true)}
            >
              <MdMenu />
            </IconButton>
            <Typography variant="h6">{title}</Typography>
            {button && button}
          </Toolbar>
        </AppBar>
      ) : (
        <nav className="header navbar navbar-expand-lg navbar-light bg-white p-0">
          <div className="container">
            <Link className="navbar-brand" to="/">
              <img src="/logo.png" alt="CAR CRM" height="40" />
            </Link>

            <ul className="navbar-nav">
              <li className="nav-item dropdown">
                <Link
                  className="nav-link dropdown-toggle"
                  data-toggle="dropdown"
                  to="/veiculos"
                >
                  <FaCar className="icon-lg mr-2" /> Veículos
                </Link>
                <MenuList className="dropdown-menu">
                  <MenuItem
                    component={Link}
                    className="dropdown-item"
                    to="/veiculos/criar"
                  >
                    Criar
                  </MenuItem>
                </MenuList>
              </li>
              <li className="nav-item">
                <button className="nav-link bg-white" to="/veiculos">
                  <FaUsers className="icon-lg mr-2" /> Proprietário
                </button>
              </li>
              <li className="nav-item dropdown">
                <Link
                  className="nav-link dropdown-toggle"
                  to="#"
                  data-toggle="dropdown"
                >
                  <FaLaptop className="icon-lg mr-2" /> Site
                </Link>
                <MenuList className="dropdown-menu">
                  <MenuItem className="dropdown-item">
                    Otimização para o Google
                  </MenuItem>
                  <MenuItem className="dropdown-item">
                    Unidades e Telefones
                  </MenuItem>
                  <MenuItem className="dropdown-item">Minha Logo</MenuItem>
                  <MenuItem className="dropdown-item">Domínio</MenuItem>
                  <MenuItem className="dropdown-item">Configurações</MenuItem>
                </MenuList>
              </li>
              <li className="nav-item dropdown">
                <Link
                  className="nav-link dropdown-toggle"
                  to="#"
                  data-toggle="dropdown"
                >
                  <FaCreditCard className="icon-lg mr-2" /> Financeiro
                </Link>
                <MenuList className="dropdown-menu">
                  <MenuItem className="dropdown-item">Meu Plano</MenuItem>
                  <MenuItem className="dropdown-item">
                    Minhas Transações
                  </MenuItem>
                </MenuList>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/">
                  <FaWhatsapp className="icon-lg mr-2" /> Ajuda
                </Link>
              </li>
              <li className="nav-item">
                <Link
                  className="nav-link"
                  to={"/login"}
                  onClick={() => {
                    dispatch(logout());
                    window.location.href = "/login";
                  }}
                >
                  <FaSignOutAlt className="icon-lg mr-2" /> Sair
                </Link>
              </li>
            </ul>
          </div>
        </nav>
      )}

      <Drawer anchor="left" open={menuOpen} onClose={() => setMenuOpen(false)}>
        <div style={{ width: 320, maxWidth: window.innerWidth - 70 }}>
          <List component="nav" className="menu-mobile">
            <ListItem>
              <img
                className="img-fuild logo-mobile"
                src="/logo.png"
                alt="CAR CRM"
              />
            </ListItem>
            <Divider className="mt-2 mb-3" />
            <ListItem>teste@teste.com</ListItem>
            <ListItem>
              <ListItemIcon>
                <FaCar />
              </ListItemIcon>
              <ListItemText primary="Veículos" />
            </ListItem>
            <ListItem>
              <ListItemIcon>
                <FaUsers />
              </ListItemIcon>
              <ListItemText primary="Proprietários" />
            </ListItem>
            <ListItem button onClick={() => setCollapseSite(!collapseSite)}>
              <ListItemIcon>
                <FaLaptop />
              </ListItemIcon>
              <ListItemText primary="Site" />
              {collapseSite ? <FaAngleUp /> : <FaAngleDown />}
            </ListItem>
            <Collapse in={collapseSite} timeout="auto" unmountOnExit>
              <List component="div" disablePadding>
                <ListItem>
                  <ListItemText
                    className="pl-5"
                    primary="Otimização para o Google"
                  />
                </ListItem>
                <ListItem>
                  <ListItemText
                    className="pl-5"
                    primary="Unidades e Telefones"
                  />
                </ListItem>
                <ListItem>
                  <ListItemText className="pl-5" primary="Minha Logo" />
                </ListItem>
                <ListItem>
                  <ListItemText className="pl-5" primary="Domínio" />
                </ListItem>
                <ListItem>
                  <ListItemText className="pl-5" primary="Configurações" />
                </ListItem>
              </List>
            </Collapse>
            <Divider className="mt-2 mb-2" />

            <ListItem
              button
              onClick={() => setCollapseFinance(!collapseFinance)}
            >
              <ListItemIcon>
                <FaCreditCard />
              </ListItemIcon>
              <ListItemText primary="Financeiro" />
              {collapseFinance ? <FaAngleUp /> : <FaAngleDown />}
            </ListItem>
            <Collapse in={collapseFinance} timeout="auto" unmountOnExit>
              <List component="div" disablePadding>
                <ListItem>
                  <ListItemText className="pl-5" primary="Meu Plano" />
                </ListItem>
                <ListItem>
                  <ListItemText className="pl-5" primary="Minhas Transações" />
                </ListItem>
              </List>
            </Collapse>

            <ListItem>
              <ListItemIcon>
                <FaWhatsapp />
              </ListItemIcon>
              <ListItemText primary="Ajuda" />
            </ListItem>

            <Divider className="mt-2 mb-2" />

            <ListItem>
              <ListItemIcon>
                <FaSignOutAlt />
              </ListItemIcon>
              <ListItemText primary="Sair" />
            </ListItem>
          </List>
        </div>
      </Drawer>
    </>
  );
}
