import React from "react";
import { Typography, Modal, CircularProgress } from "@material-ui/core";
import { useSelector, useDispatch } from "react-redux";
import { changeLoaging } from "./../../store/actions/loading.actions";

export default function Loaging() {
  const dispatch = useDispatch();
  const loading = useSelector((state) => state.loadingReducer);

  return (
    <Modal
      open={loading.open}
      onClose={() => dispatch(changeLoaging({ open: false }))}
      className="d-flex justify-content-center align-items-center h-100"
    >
      <div className="bg-white d-flex align-items-center rounded-lg p-3">
        <CircularProgress size={20} className="mr-3" />
        <Typography variant="subtitle1">{loading.message}</Typography>
      </div>
    </Modal>
  );
}
