import React from "react";
import { Provider } from "react-redux";
import { BrowserRouter } from "react-router-dom";
import { createMuiTheme, ThemeProvider } from "@material-ui/core/styles";
import { blue } from "@material-ui/core/colors";
import Routes from "./Routes";
import { store } from "./store";

import { Loading, Notify, Alert } from "./components";

const theme = createMuiTheme({
  palette: {
    primary: {
      main: blue[500]
    }
  },
  props: {
    MuiTextField: {
      variant: "outlined",
      fullWidth: true
    },
    MuiSelect: {
      variant: "outlined",
      fullWidth: true
    }
  }
});

export default function App() {
  return (
    <Provider store={store}>
      <ThemeProvider theme={theme}>
        <BrowserRouter>
          <Loading />
          <Notify />
          <Alert />
          <Routes />
        </BrowserRouter>
      </ThemeProvider>
    </Provider>
  );
}
